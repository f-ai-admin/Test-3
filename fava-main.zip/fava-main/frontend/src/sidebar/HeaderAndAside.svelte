<script lang="ts">
  import AsideWithButton from "./AsideWithButton.svelte";
  import Header from "./Header.svelte";
</script>

<Header />
<AsideWithButton />
