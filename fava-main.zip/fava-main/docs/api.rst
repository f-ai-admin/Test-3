API Documentation
=================

.. note:: There's no stability guarantee as this is just for internal purposes currently.

.. toctree::
    :glob:

    api/fava*

