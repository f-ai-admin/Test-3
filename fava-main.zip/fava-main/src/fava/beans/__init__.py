"""Types, functions and wrappers to deal with Beancount types."""
